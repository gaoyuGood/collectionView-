//
//  MyCell.h
//  UI16_UICollectionView
//
//  Created by dllo on 15/12/29.
//  Copyright © 2015年 dllo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyCell : UICollectionViewCell


@property(nonatomic,retain)UIImageView *picImageView;
@property(nonatomic,retain)UILabel *label;

@end
