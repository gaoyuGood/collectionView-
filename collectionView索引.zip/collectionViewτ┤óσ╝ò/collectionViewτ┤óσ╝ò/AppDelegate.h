//
//  AppDelegate.h
//  collectionView索引
//
//  Created by 高宇 on 2018/9/16.
//  Copyright © 2018年 高宇. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

