//
//  MyCell.m
//  UI16_UICollectionView
//
//  Created by dllo on 15/12/29.
//  Copyright © 2015年 dllo. All rights reserved.
//

#import "MyCell.h"

@implementation MyCell
-(id)initWithFrame:(CGRect)frame{
    self=[super initWithFrame:frame];
    if (self) {
        [self createView];
    }
    return self;
}
-(void)createView{
    self.label=[[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height/3)];
    [self addSubview:self.label];
    
    self.picImageView=[[UIImageView alloc] initWithFrame:CGRectMake(0, self.frame.size.height/3, self.frame.size.width, self.frame.size.height/3*2)];
    self.picImageView.image = [UIImage imageNamed:@"dog"];
    [self addSubview:self.picImageView];
    
}







@end
