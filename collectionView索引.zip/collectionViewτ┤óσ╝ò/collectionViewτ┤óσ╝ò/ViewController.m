//
//  ViewController.m
//  collectionView索引
//
//  Created by 高宇 on 2018/9/16.
//  Copyright © 2018年 高宇. All rights reserved.
//

#import "ViewController.h"
#import "DSCollectionViewIndex.h"
#import "MyCell.h"  //自定义cell

#define SCREEN_WIDTH  self.view.bounds.size.width
#define SCREEN_HEIGHT  self.view.bounds.size.height
//判断是否为iPhone X
#define kDevice_Is_iPhoneX ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1125, 2436), [[UIScreen mainScreen] currentMode].size) : NO)
#define kDevice_NavBar_Hight (kDevice_Is_iPhoneX?88:64)
#define kDevice_StatusBar_Hight (kDevice_Is_iPhoneX?44:20)
#define kDevice_SafeArea_OffsetY (kDevice_Is_iPhoneX?34:0)              //竖屏底部safeArea
#define kDevice_SafeArea_OffsetY_horizontal (kDevice_Is_iPhoneX?21:0)   //横屏底部safeArea

@interface ViewController ()<UICollectionViewDataSource,UICollectionViewDelegate,DSCollectionViewIndexDelegate>
{
    DSCollectionViewIndex *_collectionViewIndex;   //右边索引条
    NSMutableArray *rows;  //索引数组
    UILabel  *_flotageLabel;     //中间显示的背景框
    UIView *flotageView;    //选中字母改变背景
}
@property (nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic, strong) NSMutableArray* data; //数据数组
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self.view addSubview:self.collectionView];   //懒加载collectionView
    
    self.data = [NSMutableArray arrayWithArray:@[@"安卓", @"宝丽来",@"霸王别姬",@"菜鸟",@"facebook",@"菲尔可",@"飞利浦",@"谷歌",@"海尔",@"海信",@"华为",@"iPhone",@"iPad",@"Mac book",@"松下"]];   //创建数据的数组
    
    [self createCollectionViewIndex];  //创建索引条
}

#pragma mark 索引条
- (void)createCollectionViewIndex{
    _collectionViewIndex = [[DSCollectionViewIndex alloc] initWithFrame:CGRectMake(SCREEN_WIDTH-20, 0, 20, SCREEN_HEIGHT)];    //创建索引条
    [self.view addSubview:_collectionViewIndex];   //添加到视图上
    NSMutableArray *sections = [NSMutableArray array];    //创建字母数组   @[@"A", @"D", @"F", @"M", @"N", @"Z"];
    rows = [NSMutableArray array];  //创建索引数组   @[@[@"adam", @"alfred"],@[@"bo"]];
    int indexsInt = -1;    //更新索引数组元素的数值
    NSString *tempStr = @"temp";    //交换字母,用来判断该字母是否存在的数值
    for (NSString *nameStr in self.data) {
        NSString *pinyin = [self transformToPinyin:nameStr];    //将中文字符串转换为拼音格式
        if ([pinyin isEqualToString:@"zhang hong"]) {   //排错   长虹转换为拼音错误
            pinyin = @"chang hong";
        }
        NSString *testUpFirst = [pinyin capitalizedString];      //首字母大写
        NSString *firstLetterStirng = [testUpFirst substringToIndex:1];    //取出字符串第一位字母
        
        if (firstLetterStirng == tempStr) {   //判断该字母是否为上一位存在的
            [rows[indexsInt] addObject:firstLetterStirng];   //加入对应数组中
        }else{
            [sections addObject:firstLetterStirng];   //字母数组添加新字母
            NSMutableArray *array = [NSMutableArray array];   //生成新字母数组
            [array addObject:firstLetterStirng];
            [rows addObject:array];     //索引数组添加新字母数组
            indexsInt = indexsInt + 1;    //索引数组count+1
            tempStr = firstLetterStirng;    //上一位字母更换为新字母
        }
    }
    
    _collectionViewIndex.titleIndexes = sections;   //设置数组
    CGRect rect = _collectionViewIndex.frame;
    rect.size.height = _collectionViewIndex.titleIndexes.count * 16;
    rect.origin.y = (SCREEN_HEIGHT - rect.size.height) / 2;
    _collectionViewIndex.frame = rect;
    _collectionViewIndex.isFrameLayer = NO;    //是否有边框线
    _collectionViewIndex.collectionDelegate = self;
    
    
    //中间显示的背景框
    _flotageLabel = [[UILabel alloc] initWithFrame:(CGRect){(SCREEN_WIDTH - 64 ) / 2,(SCREEN_HEIGHT - 64) / 2,64,64}];
    CGRect flotageRect = _flotageLabel.frame;
    flotageRect.origin.y = (SCREEN_HEIGHT - flotageRect.size.height) / 2;
    _flotageLabel.frame = flotageRect;
    _flotageLabel.backgroundColor = [UIColor grayColor];
    _flotageLabel.hidden = YES;
    _flotageLabel.textAlignment = NSTextAlignmentCenter;
    _flotageLabel.textColor = [UIColor whiteColor];
    [self.view addSubview:_flotageLabel];
    
    //选中字母改变背景
    flotageView = [[UIView alloc] init];
    flotageView.frame = CGRectMake(0, 0, _collectionViewIndex.frame.size.width, 16);
    flotageView.hidden = YES;
    flotageView.alpha = 0.5;
    flotageView.layer.cornerRadius = 8;
    flotageView.layer.masksToBounds = YES;
    flotageView.backgroundColor = [UIColor grayColor];
    [_collectionViewIndex addSubview:flotageView];
}

#pragma mark- 索引条代理DSCollectionViewIndexDelegate

-(void)collectionViewIndex:(DSCollectionViewIndex *)collectionViewIndex didselectionAtIndex:(NSInteger)index withTitle:(NSString *)title{
    NSInteger tempInt = 0;
    NSArray *array = [NSArray array];
    for (int i=0; i<index ; i++) {    //根据循环rows数组得到需要滑动到的位置
        array = rows[i];
        tempInt = tempInt + array.count;
    }
    [_collectionView scrollToItemAtIndexPath:[NSIndexPath indexPathForItem:tempInt inSection:0] atScrollPosition:UICollectionViewScrollPositionTop animated:YES];
    _flotageLabel.text = title;
    //
    CGRect rect = flotageView.frame;
    rect.origin.y = index * 16;
    flotageView.frame = rect;
}

-(void)collectionViewIndexTouchesBegan:(DSCollectionViewIndex *)collectionViewIndex{
    _flotageLabel.alpha = 1;
    _flotageLabel.hidden = NO;
    //
    flotageView.hidden = NO;
}

-(void)collectionViewIndexTouchesEnd:(DSCollectionViewIndex *)collectionViewIndex{
    void (^animation)() = ^{
        _flotageLabel.alpha = 0;
        flotageView.hidden = YES;
    };
    
    [UIView animateWithDuration:0.4 animations:animation completion:^(BOOL finished) {
        _flotageLabel.hidden = YES;
    }];
}


/**
 将中文字符串转换为拼音格式（不带声调）
 @return 返回不带声调拼音字符串
 */
- (NSString *)transformToPinyin:(NSString *)str
{
    // 空值判断
    if (str == nil || str == NULL) {
        return @"";
    }
    // 将字符串转为NSMutableString类型
    NSMutableString *string = [str mutableCopy];
    // 将字符串转换为拼音音调格式
    CFStringTransform((__bridge CFMutableStringRef)string, NULL, kCFStringTransformMandarinLatin, NO);
    // 去掉音调符号
    CFStringTransform((__bridge CFMutableStringRef)string, NULL, kCFStringTransformStripDiacritics, NO);
    // 返回不带声调拼音字符串
    return string;
}


#pragma mark collectionView协议方法
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.data.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    MyCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:@"MyCell" forIndexPath:indexPath];
    
    cell.label.text=[NSString stringWithFormat:@"%@",self.data[indexPath.row]];
    
    return cell;
}

#pragma mark set方法
- (UICollectionView *)collectionView
{
    if (!_collectionView) {
        UICollectionViewFlowLayout *flowLayout = [UICollectionViewFlowLayout new];
        flowLayout.itemSize=CGSizeMake(SCREEN_WIDTH/2-1, 240);
        flowLayout.minimumInteritemSpacing = 1;
        flowLayout.minimumLineSpacing = 1;
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT) collectionViewLayout:flowLayout];
        _collectionView.backgroundColor = [UIColor whiteColor];
        _collectionView.dataSource = self;
        _collectionView.delegate = self;
        [_collectionView registerClass:[MyCell class] forCellWithReuseIdentifier:@"MyCell"];
    }
    return _collectionView;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
