//
//  main.m
//  collectionView索引
//
//  Created by 高宇 on 2018/9/16.
//  Copyright © 2018年 高宇. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
